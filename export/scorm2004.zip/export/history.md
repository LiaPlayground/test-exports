# History of LiaScript.md

---------------------------------------
17-02-2022_16-12-29 - SebastianZug - Merge branch 'dev' of github.com:LiaPlayground/test-exports into dev

17-02-2022_16-18-17 - SebastianZug -Revise history file structure
